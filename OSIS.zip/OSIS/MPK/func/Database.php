<?php  

$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'MPK';

$mysqli = new mysqli($host, $user, $pass, $db);

if($mysqli->connect_errno){
	echo $mysqli->connect_error;
}

?>