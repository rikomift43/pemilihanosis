<?php  

$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'OSIS';

$mysqli = new mysqli($host, $user, $pass, $db);

if($mysqli->connect_errno){
	echo $mysqli->connect_error;
}

?>