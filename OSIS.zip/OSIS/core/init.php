<?php  

session_start();

require_once 'func/Database.php';
require_once 'func/Calon.php';
require_once 'func/Pilih.php';

?>